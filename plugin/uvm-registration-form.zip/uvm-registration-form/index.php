<?php 
//Silence is golden.