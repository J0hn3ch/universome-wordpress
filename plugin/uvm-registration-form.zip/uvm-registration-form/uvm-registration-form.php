<?php
/*
Plugin Name: UVM Registration form
Plugin URI: https://github.com/J0hn3ch
Description: Registration form to put in a page for the web site universome.eu
Author: Gianluca Carbone
Version: 0.0.1
Author URI: https://github.com/J0hn3ch
*/

/* =====[ ACTIVATION ]===== */
register_activation_hook( __FILE__, 'uvm_registration_form_activate' );
function uvm_registration_form_activate() {

    add_option( 'Activated_Plugin', 'UVM-Registration-Form' );

    require_once (dirname(__FILE__) . '/includes/uvm-register-form.php');

    /* activation code here */
    uvm_registration_load();

    // Clear the permalinks after the post type has been registered.
    flush_rewrite_rules();
}

function uvm_registration_load(){
    if ( is_admin() && get_option( 'Activated_Plugin' ) == 'UVM-Registration-Form' ) {

        delete_option( 'Activated_Plugin' );
        
        add_shortcode('uvm_registration_form', 'uvm_registration_form');
    }
}
add_action( 'admin_init', 'uvm_registration_load' );

/* =====[ DEACTIVATION ]===== */
// Call deactivate_PLUGINAME action
function uvm_registration_form_deactivate() {

    add_option( 'Activated_Plugin', 'UVM-Reg' );

    /* deactivation code here */
    uvm_registration_deactivation();

    // Clear the permalinks to remove our post type's rules from the database.
    flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'uvm_registration_form_deactivate' );

function uvm_registration_deactivation(){
    remove_shortcode( 'uvm_registration_form' );
}